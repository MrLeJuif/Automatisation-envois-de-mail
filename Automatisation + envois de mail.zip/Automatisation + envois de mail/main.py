# CE PROJET CONSISTE A AUTOMATISER LA FACTURATION

# Nous allons d'abord importer la bibliotheque nous permettant d'ouvrir les fichiers Excels
# os.path.dirname(os.path.realpath(__file__)) cette ligne de code permet de donner le dosser actuel du fichier python


import openpyxl
import os
from os import walk # Cette bibliotheque permet de parcourir un dossier
import emails_config # l'import de mon propre fichier
import smtplib # Permet d envoyer un mail simple
from email.mime.multipart import MIMEMultipart # Ceci permet d envoyer un mail avec plus d infos
from email.mime.text import MIMEText # Nous permet d'ajouter un mime de type texte*
from email.mime.base import MIMEBase
from email import encoders


"""
# Cette fonction permet de compter le nombre de fichier dans ce dossier
initial_count = 0
dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "excels")
for path in os.listdir(dir):
    if os.path.isfile(os.path.join(dir, path)):
        initial_count += 1"""

# Cette fonction permet de lister les fichiers dans un dossier
dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "excels")
liste_fichiers = []
for (dirpath, dirnames, filenames) in walk(dir):
    liste_fichiers.extend(filenames)
    break

# Nous allons extraire tous les workbooks
wbs = []
for f in liste_fichiers:
    dir_file = os.path.join(dir, f)
    wbs.append(openpyxl.load_workbook(dir_file, data_only=True))
    # print(wbs[i][wbs[i].sheetnames[0]]["A1"].value)

# Creation d'une fonction qui nous permettra d extraire le données
def ajouter_data_depuis_wb(wb, d):
    sheet = wb.active
    for row in range(2, sheet.max_row):
        nom_article = sheet.cell(row, 1).value
        if not nom_article:
            break
        prix_unit = sheet.cell(row, 2).value
        qte_vente = sheet.cell(row, 3).value
        total_ventes = sheet.cell(row, 4).value
        if d.get(nom_article):
            d[nom_article][0].append(prix_unit)
            d[nom_article][1].append(qte_vente)
            d[nom_article][2].append(total_ventes)
        else:
            d[nom_article] = [[prix_unit], [qte_vente], [total_ventes]]


donnees = {}
for wb in wbs:
    ajouter_data_depuis_wb(wb, donnees)

#print(donnees)

# Nous allons ensuite créer notre fichier Excel
# En commençant par initialiser les entêtes des colonnes
wb_sortie = openpyxl.Workbook()
sheet = wb_sortie.active
sheet["A1"] = "Article"
# sheet["B1"] = "Prix unitaire"
sheet["B1"] = "Quantite vendue"
sheet["C1"] = "Janvier"
sheet["D1"] = "Fevrier"
sheet["E1"] = "Mars"
sheet["F1"] = "Avril"
sheet["G1"] = "Mai"
sheet["H1"] = "Juin"
sheet["I1"] = "Juillet"
sheet["J1"] = "Aout"
sheet["K1"] = "Septembre"
sheet["L1"] = "Octobre"
sheet["M1"] = "Novembre"
sheet["N1"] = "Decembre"


# Nous allons ensuite remplir le fichier Excel
row = 2
for i in donnees.items():
    nom_article = i[0]
    qte = sum(i[1][1])
    ventes = i[1][2]
    sheet.cell(row, 1).value = nom_article
    sheet.cell(row, 2).value = qte
    for j in range(0, len(ventes)):
        sheet.cell(row, j+3).value = ventes[j]
    row += 1


# Ajout de graphes
# 1er graphe
chart_ref = openpyxl.chart.Reference(sheet, min_col=2, min_row=2, max_col=sheet.max_column, max_row=2)
chart_serie = openpyxl.chart.Series(chart_ref, title="Totale des ventes de Pommes sur l'année")
chart = openpyxl.chart.BarChart()
chart.title = "Evolution du prix sur l'année"
chart.append(chart_serie)

sheet.add_chart(chart, "A8")


# 2eme graphe
chart_ref = openpyxl.chart.Reference(sheet, min_col=2, min_row=3, max_col=sheet.max_column, max_row=3)
chart_serie = openpyxl.chart.Series(chart_ref, title="Totale des ventes de Poires sur l'année")
chart = openpyxl.chart.BarChart()
chart.title = "Evolution du prix sur l'année"
chart.append(chart_serie)

sheet.add_chart(chart, "J8")


# 3eme graphe
chart_ref = openpyxl.chart.Reference(sheet, min_col=2, min_row=4, max_col=sheet.max_column, max_row=4)
chart_serie = openpyxl.chart.Series(chart_ref, title="Totale des ventes de Bananes sur l'année")
chart = openpyxl.chart.BarChart()
chart.title = "Evolution du prix sur l'année"
chart.append(chart_serie)

sheet.add_chart(chart, "A23")


# 4eme graphe
chart_ref = openpyxl.chart.Reference(sheet, min_col=2, min_row=5, max_col=sheet.max_column, max_row=5)
chart_serie = openpyxl.chart.Series(chart_ref, title="Totale des ventes de Mangues sur l'année")
chart = openpyxl.chart.BarChart()
chart.title = "Evolution du prix sur l'année"
chart.append(chart_serie)

sheet.add_chart(chart, "J23")


# 5eme graphe
chart_ref = openpyxl.chart.Reference(sheet, min_col=2, min_row=6, max_col=sheet.max_column, max_row=6)
chart_serie = openpyxl.chart.Series(chart_ref, title="Totale des ventes d'Ananas sur l'année")
chart = openpyxl.chart.BarChart()
chart.title = "Evolution du prix sur l'année"
chart.append(chart_serie)

sheet.add_chart(chart, "A38")

# Creation du fichier de sortie
wb_sortie.save(os.path.join("total", "Total_ventes_annuelles.xlsx"))


# Envois par mail
#Creation de la fonction à àutiliser

def envoyer_email(email_destinataire, sujet, message):

    multipart_message = MIMEMultipart()
    multipart_message["Subject"] = sujet
    multipart_message["From"] = emails_config.config_email
    multipart_message["To"] = email_destinataire

    multipart_message.attach(MIMEText(message, "plain"))

    # locate and attach desired attachments
    part = MIMEBase('application', "octet-stream")
    part.set_payload(open(os.path.join("total", "Total_ventes_annuelles.xlsx"), "rb").read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="Total_ventes_annuelles.xlsx"')
    multipart_message.attach(part)

    serveur_mail = smtplib.SMTP(emails_config.config_server, emails_config.config_server_port)
    serveur_mail.starttls()
    serveur_mail.login(emails_config.config_email, emails_config.config_password)
    serveur_mail.sendmail(emails_config.config_email, email_destinataire, multipart_message.as_string())
    serveur_mail.quit()


message = """
Bonjour,
Veuillez la facture annuelle

Cordialement,
ANAGKAZO BI
0709778821
"""

question = input("Souhaitez-vous envoyez le fichier par mail (y/n) ? ")
if question == "y":
    envoyer_email("lanagkazo@gmail.com", "Message d'ANAGKAZO BI", message)
    print("Email envoyé :)")
else:
    print("Aucun mail envoyé :(")




